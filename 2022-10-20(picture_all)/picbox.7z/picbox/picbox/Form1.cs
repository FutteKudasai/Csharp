﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace picbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label3.Text = "圖框的寬度 = "+pictureBox1.Width.ToString();
            label4.Text = "圖框的高度 = " + pictureBox1.Height.ToString();
        }


        private void Button1_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Normal;
            label7.Text = ("pictureBox1.SizeMode = PictureBoxSizeMode.Normal");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            label7.Text = ("pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage");
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            label7.Text = ("pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize");
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            label7.Text = ("pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage");
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            label7.Text = ("pictureBox1.SizeMode = PictureBoxSizeMode.Zoom");
         }

        private void Button6_Click(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImageLayout = ImageLayout.None;
            label7.Text = ("pictureBox1.BackgroundImageLayout = ImageLayout.None");
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImageLayout = ImageLayout.Tile;
            label7.Text = ("pictureBox1.BackgroundImageLayout = ImageLayout.Tile");
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            label7.Text = ("pictureBox1.BackgroundImageLayout = ImageLayout.Stretch");
        }

        private void Button9_Click(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImageLayout = ImageLayout.Center;
            label7.Text = ("pictureBox1.BackgroundImageLayout = ImageLayout.Center");
        }

        private void Button10_Click(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            label7.Text = ("pictureBox1.BackgroundImageLayout = ImageLayout.Zoom");
        }

        private void GroupBox2_Enter(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImage = null;
            pictureBox1.Image = new Bitmap("dog1.jpg"); 
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImage = Image.FromFile("imagetable.jpg");
            pictureBox1.Image = null;
        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {
            try
            {
                pictureBox1.Location = new Point(Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox3.Text));
                label1.Text = "圖框的位置X=" + (pictureBox1.Location.X).ToString();
                label2.Text = "圖框的位置Y=" + (pictureBox1.Location.Y).ToString();
            }
            catch
            {}
        }

        private void button11_Click(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImage = Image.FromFile("imagetable.jpg");
            pictureBox1.Image = new Bitmap("dog1.jpg");
            pictureBox1.BackgroundImageLayout = ImageLayout.Tile;
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;

        }
    }
}
